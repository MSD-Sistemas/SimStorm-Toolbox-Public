function updGraph(dadosProd, dadosCons) { 
var chProd = document.getElementById("grafProducao");
var chCons = document.getElementById("grafConsumo");
var colors = ["#007bff","#28a745","#333333","#dc3545","#e3e308","#6c757d"];

// Produção
var dataProd = {
labels: ["Água-Óleosa", "Gás Natural", "Óleo"],
datasets: [{
backgroundColor: colors.slice(0,3),
borderWidth: 0,
data: dadosProd
}]};

if (chProd) {
  new Chart(chProd, {
  type: "pie",
  data: dataProd,
  options: donutOptions
  });
}

// Produção
var dataCons = {
labels: ["Energia Térmica", "Energia Elétrica"],
datasets: [
  {
backgroundColor: colors.slice(3,5),
borderWidth: 0,
data: dadosCons
  }
]
};

if (chCons) {
  new Chart(chCons, {
  type: "pie",
  data: dataCons,
  options: donutOptions
  });
}
var donutOptions = {
  cutoutPercentage: 85, 
  legend: {position:"bottom", padding:5, labels: {pointStyle:"circle", usePointStyle:true}}
};
}